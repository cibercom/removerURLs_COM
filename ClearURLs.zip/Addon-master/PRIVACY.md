ClearURLs protects and respects your privacy. 
We do not collect any of your usage data. Furthermore, ClearURLs has no home server nor embed any kind of analytic hooks in its code.

The only time ClearURLs connects to a remote server (gitlab.io or github.io) is to update the rules file and the associated hash file. You can replace the default update address (_rules1.clearurls.xyz_/_rules2.clearurls.xyz_) with your address at any time in the settings.

The project and the rule file are currently hosted on gitlab.com and github.com, which is owned by GitLab Inc. and GitHub Inc. Thus they are unrelated to ClearURLs. The _rules1.clearurls.xyz_ and _rules2.clearurls.xyz_ addresses are just CNAME records and thus we got no information about the request.
